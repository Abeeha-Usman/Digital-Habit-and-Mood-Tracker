#include <iostream>
#include <fstream>
#include <string>
using namespace std;

void addRecord()
{
    string date, name, mood;
    int sleep, study;
    char exercise, prayer;
    ofstream habitFile("habit_data.txt", ios::app);
    ofstream moodFile("mood_data.txt", ios::app);
    if (!habitFile||!moodFile)
    {
        cout<<"File not found"<<endl;
        return;
    }

    cout<<"Enter date (DD-MM-YY): ";
    cin>>date;
    cout<<"Enter name: ";
    cin>>name;
    cout<<"Sleep hours: ";
    cin>>sleep;
    cout<<"Study hours: ";
    cin>>study;
    cout<<"Exercise (Y/N): ";
    cin>>exercise;
    cout<<"Prayer (Y/N): ";
    cin>>prayer;
    cout<<"Mood (Happy/Stressed/Tired/Calm): ";
    cin>>mood;
    
    habitFile<<date<<" "<<name<<" "<<sleep<<" "<<study<<" "<<exercise<<" "<<prayer<<endl;
    moodFile<<date<<" "<<mood<<endl;

    habitFile.close();
    moodFile.close();
    cout<<endl<<"---Record added sucessfully---"<<endl;
}

void viewRecords()
{
    ifstream habitFile("habit_data.txt");
    if (!habitFile)
    {
        cout<<"No record found"<<endl;
        return;
    }

    string date, name;
    int sleep, study;
    char exercise, prayer;
    cout<<endl<<"---All Records---\n"<<endl;
    while (habitFile>>date>>name>>sleep>>study>>exercise>>prayer)
    {
        cout<<date<<" "<<name<<" "<< sleep<<" "<<study<< " "<<exercise<<" "<<prayer<<endl;
    }
    
    habitFile.close();
}

void weeklySummary()
{
    ifstream habitFile("habit_data.txt");
    ifstream moodFile("mood_data.txt");

    if (!habitFile || !moodFile)
    {
        cout<<"File missing"<<endl;
        return;
    }

    string date, name, mood;
    int sleep, study;
    char exercise, prayer;

    int count = 0;
    int goodStudy = 0, goodSleep = 0;
    int exDays = 0, prDays = 0;
    int happy = 0, stressed = 0, tired = 0, calm = 0;

    cout<<endl<<"---Weekly Summary---"<<endl;

    while (habitFile>>date>>name>>sleep>>study>>exercise>>prayer&&count<7)
    {
        if (study>=6)
        goodStudy++;
        if (sleep>=8)
        goodSleep++;
        if (exercise=='Y'||exercise=='y')
        exDays++;
        if (prayer=='Y'||prayer=='y')
        prDays++;
        count++;
    }

    while (moodFile>>date>>mood)
    {
        if (mood=="Happy"||mood=="happy")
        happy++;
        else if (mood=="Stressed"||mood=="stressed")
        stressed++;
        else if (mood=="Tired"||mood=="tired")
        tired++;
        else if (mood=="Calm"||mood=="calm")
        calm++;
    }

    cout<<"Good study days: "<<goodStudy<<endl;
    cout<<"Good sleep days: "<<goodSleep<<endl;
    cout<<"Exercise days: "<<exDays<<endl;
    cout<<"Prayer days: "<<prDays<<endl;
    cout<<"Mood count"<<endl;
    cout<<"Happy: " <<happy<<endl;
    cout<<"Stressed: "<<stressed<<endl;
    cout<<"Tired: "<<tired<<endl;
    cout<<"Calm: "<<calm<<endl;

    habitFile.close();
    moodFile.close();
}

int main()
{
    int choice;
    do
    {
    	cout<<endl;
        cout<<"Digital Habit and Mood Tracker"<<endl;
        cout<<"1. Add Daily Record"<<endl;
        cout<<"2. View Records"<<endl;
        cout<< "3. Weekly Summary"<<endl;
        cout<< "4. Exit"<<endl;
        cout<<"Enter choice: ";
        cin>>choice;
        if (choice==1)
        addRecord();
        else if (choice==2)
        viewRecords();
        else if (choice==3)
        weeklySummary();
        else if (choice==4)
        cout<<endl<<"-----------Program Exit-----------"<<endl;
        else
        cout<<"****** Invalid choice ******"<<endl;

    } while (choice!=4);
    return 0;
}

